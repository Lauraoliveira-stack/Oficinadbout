# 🎮 OFICINA CONVERSÃO MÁXIMA — DBout Mídia

Site da oficina prática DBout (60 min ao vivo, online, +200 participantes). Game + treinamento + certificado.

## 🚀 Publicar no Netlify
1. https://app.netlify.com/drop
2. Arrasta a pasta `dbout-oficina` (ou só `index.html`)
3. URL pública na hora · compartilha com os participantes

## 🎯 Como funciona (durante a oficina)

### Antes de começar
1. Você manda a URL no grupo do WhatsApp/Zoom chat: `https://oficinadbout.netlify.app` (ou o link gerado)
2. Cada participante abre no celular ou notebook

### Fluxo da Oficina (60 min)

**📍 PARTE 1 — Abertura (5 min)**
- Você se apresenta no Zoom/Meet
- Pede pra cada um abrir o site e entrar (nome + unidade + emoji do "bonequinho")
- Mostra na sua tela quem chegou (tela de "Jogadores na Arena")

**📍 PARTE 2 — Game (35 min)**
- 23 perguntas, 25-50s cada
- Tipos: Múltipla escolha · Verdadeiro/Falso · Nuvem de palavras · Coloque em ordem · Multi-seleção
- Após cada pergunta, aparece a resposta correta e o "por quê" — você comenta ao vivo enquanto eles veem na tela deles
- O score aparece em tempo real pra cada um

**📍 PARTE 3 — Motivacional (15 min)**
- Pirâmide de Consciência do Lead
- Os 7 erros que quebram a conversão
- Comparativo "atendimento que CONVERTE vs NÃO converte" (com os prints reais)

**📍 ENCERRAMENTO (5 min)**
- Score final + estatísticas
- QR code pra avaliação da oficina (e estrelas no site)
- Cada um preenche nome+unidade+telefone pra gerar o CERTIFICADO em PNG
- Você anuncia o ranking ao vivo com base nos scores enviados ao seu e-mail

## 📥 Você recebe (na sua caixa)

Cada participante que termina envia automaticamente pro seu e-mail (laura@dboutmidia.com.br):
1. **Inscrição com score** (assunto: `🏆 OFICINA - Nome (Unidade) · Score 1240`)
2. **Avaliação** (assunto: `⭐ AVALIAÇÃO OFICINA - Nome · 5/5`)

Também aparece no painel Forms do Netlify (Site → Forms → oficina_inscricao / oficina_avaliacao).

## 🏆 Para apurar o ranking ao vivo

Como são 200 pessoas, o ideal é:
- Você abre seu e-mail/Netlify Forms num monitor secundário
- Conforme os participantes terminam, você vê os scores chegando
- Anuncia o TOP 3 ao vivo (você decide o critério: maior score, mais acertos rápidos, etc.)
- Eles recebem o certificado pelo site mesmo

## 📜 Certificado automático

Cada participante preenche os dados → o site gera PNG com:
- DBOUT MÍDIA + logo
- "CERTIFICADO DE PARTICIPAÇÃO"
- Nome + Unidade + Score + Data
- 2 assinaturas: **Laura Oliveira** (Head de Pós-Vendas) + **Luis Parrela** (CEO)

## 🎨 Visual
- Arcade neon (rosa, ciano, amarelo)
- Bonequinhos (emojis) representando cada participante no tabuleiro
- Timer circular com countdown
- Confetes ao acertar
- Cores de tecnologia + game

## 🛠 Customizar
- **Nome da oficina:** procure `OFICINA CONVERSÃO MÁXIMA` no `index.html`
- **E-mail:** procure `laura@dboutmidia.com.br`
- **Perguntas:** array `QUESTIONS` no `<script>`
- **Logo:** já embutida em base64 — pra trocar, substitui no objeto `ASSETS.LOGO`

## 💡 Sugestões de nomes alternativos pra oficina
1. **OFICINA CONVERSÃO MÁXIMA** (atual)
2. ARENA DBOUT — Atendimento que Converte
3. MARATONA CLÍNICA DE SUCESSO
4. JOGO DA CONVERSÃO — Edição DBout
5. BOOTCAMP CLÍNICA DE SUCESSO

Pra trocar, substitua todas as ocorrências de "OFICINA CONVERSÃO MÁXIMA" no `index.html`.

---
© 2026 DBOUT MÍDIA · Para Laura Oliveira (Head Pós-Vendas) · laura@dboutmidia.com.br
