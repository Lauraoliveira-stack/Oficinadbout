# 🚨 IMPORTANTE — Como deployar pra Functions funcionarem

O ranking AO VIVO depende de uma **Netlify Function** (`/netlify/functions/ranking.js`). Pra ela funcionar, **o drag-and-drop simples NÃO BASTA**. Você precisa de um dos 2 caminhos abaixo.

## ✅ Caminho A — Site novo, drag-and-drop da PASTA (mais fácil)

1. Acesse https://app.netlify.com (logada)
2. Na home, clique **"Add new site"** → **"Deploy manually"**
3. Arraste a **PASTA INTEIRA** `dbout-oficina` (não só o `index.html`!) pra janela
4. Aguarde o deploy
5. Depois do deploy, clique no nome do site → **Functions** (menu lateral)
6. Você deve ver `ranking` listada como função deployada ✅
7. Teste abrindo `https://[seu-site].netlify.app/api/ranking` direto no browser
   - Se devolver `[]` ou JSON → ✅ funcionando
   - Se devolver "Page not found" → ❌ algo deu errado, tenta o Caminho B

## ✅ Caminho B — Via GitHub (mais robusto, deploy automático)

1. Crie um repositório novo no GitHub (privado ou público)
2. Sobe a pasta `dbout-oficina` inteira (com `netlify/functions/ranking.js` dentro)
3. No Netlify: **Add new site** → **Import from Git** → conecta o GitHub
4. Selecione o repo
5. Build settings:
   - **Build command:** (deixa em branco)
   - **Publish directory:** `.`
6. Deploy
7. Verifique em **Functions** se `ranking` aparece

## 🔄 Atualizando o site DEPOIS

- Caminho A: arrasta a pasta de novo, mas em "Deploys" → "Drag and drop"
- Caminho B: faz push no GitHub, Netlify deploya automaticamente

## ⚠️ Erros comuns

### "Page not found" no `/api/ranking`
- **Causa 1:** Deploy não incluiu a pasta `netlify/functions/`
- **Causa 2:** O `netlify.toml` não foi enviado junto
- **Fix:** sobe TUDO de novo, incluindo `netlify.toml` e `package.json`

### "Function failed to load" no painel
- **Causa:** Falta a dependência `@netlify/blobs`
- **Fix:** O `package.json` na raiz já tem isso, garante que ele subiu junto

### Site funciona mas /api/ranking dá 500
- **Causa:** Netlify Blobs não inicializou
- **Fix:** Cada deploy do Netlify ativa Blobs automaticamente — se não, vá em Site → Storage → Blobs → enable

## 🧪 Como TESTAR que está funcionando

1. Abra a URL principal: `https://[seu-site].netlify.app`
2. Vá até a tela de Ranking (no fim do jogo)
3. Olha o indicador no topo da lista:
   - 🟢 **CONECTADO · X participantes** → tudo OK
   - 🔴 **SERVIDOR OFFLINE** → Function não deployada
4. No modo host (`?host=true`), clica em **🔌 TESTAR API** — popup mostra o status

## 📞 Se travar

Manda print do painel de Functions do Netlify pra Laura e/ou pro Claude — em 99% dos casos o problema é o arquivo `netlify.toml` ou a pasta `netlify/functions/` não terem subido.
