// Netlify Function (CommonJS — works WITHOUT build, on Drop deploys!)
// Storage: Netlify Blobs (pre-installed, no npm install needed)
const { getStore } = require('@netlify/blobs');

exports.handler = async (event) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Content-Type': 'application/json',
    'Cache-Control': 'no-store',
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 204, headers, body: '' };
  }

  let store;
  try {
    store = getStore({ name: 'oficina-ranking', consistency: 'strong' });
  } catch (e) {
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: 'blobs_init', message: e.message }),
    };
  }

  const KEY = 'scores';

  try {
    // GET — fetch ranking
    if (event.httpMethod === 'GET') {
      const data = (await store.get(KEY, { type: 'json' })) || [];
      return { statusCode: 200, headers, body: JSON.stringify(data) };
    }

    // POST — add/update score
    if (event.httpMethod === 'POST') {
      let body;
      try { body = JSON.parse(event.body || '{}'); }
      catch (e) { return { statusCode: 400, headers, body: JSON.stringify({ error: 'invalid_json' }) }; }

      if (!body.name || !body.unit || typeof body.score !== 'number') {
        return { statusCode: 400, headers, body: JSON.stringify({ error: 'missing_fields' }) };
      }

      const current = (await store.get(KEY, { type: 'json' })) || [];
      const idx = current.findIndex(
        (p) => p.name && p.unit &&
               p.name.toLowerCase() === body.name.toLowerCase() &&
               p.unit.toLowerCase() === body.unit.toLowerCase()
      );

      const entry = {
        name: String(body.name).slice(0, 60),
        unit: String(body.unit).slice(0, 80),
        piece: String(body.piece || '🎯').slice(0, 8),
        score: Math.max(0, Math.min(99999, parseInt(body.score, 10) || 0)),
        correct: parseInt(body.correct, 10) || 0,
        total: parseInt(body.total, 10) || 0,
        phone: String(body.phone || '').slice(0, 30),
        ts: Date.now(),
      };

      if (idx >= 0) {
        // Update only if new score is HIGHER
        if (entry.score >= current[idx].score) current[idx] = entry;
      } else {
        current.push(entry);
      }

      // Cap at 500 to prevent abuse