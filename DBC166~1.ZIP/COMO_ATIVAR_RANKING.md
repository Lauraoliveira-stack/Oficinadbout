# 🔥 COMO ATIVAR O RANKING AO VIVO

Como o **Netlify Drop NÃO deploya Functions** (só Git deploya), vamos usar **Firebase Realtime Database** — grátis pra sempre, sem cartão de crédito, **funciona com qualquer deploy** (inclusive o drag-and-drop simples).

## 🚀 Setup em 3 minutos

### Passo 1 — Criar projeto Firebase
1. Acesse https://console.firebase.google.com (login com Google)
2. Clique **"Add project"** (ou "Adicionar projeto")
3. Nome: `dbout-oficina` (ou o que quiser)
4. Pode desativar Google Analytics (não precisa)
5. Clique **"Create project"** → aguarda alguns segundos

### Passo 2 — Ativar o Realtime Database
1. No menu lateral esquerdo, clique **"Build" → "Realtime Database"**
2. Clique **"Create Database"**
3. Localização: escolha **"us-central1"** (ou a mais próxima)
4. Modo de segurança: escolha **"Start in TEST MODE"** (acesso público por 30 dias — perfeito pra workshop)
5. Clique **Enable**

### Passo 3 — Copiar a URL
Depois que o database for criado, no topo da página tem uma URL tipo:
```
https://dbout-oficina-default-rtdb.firebaseio.com
```
**Copia essa URL exatamente.**

### Passo 4 — Colar no index.html
Abra `index.html` num editor de texto (Notepad, VS Code, etc.) e procure pela linha:
```js
const FIREBASE_DB_URL = ""; // ← COLE A URL AQUI
```
Cole a URL entre as aspas:
```js
const FIREBASE_DB_URL = "https://dbout-oficina-default-rtdb.firebaseio.com";
```
**Salva.**

### Passo 5 — Re-deploy
Sobe o `index.html` atualizado pro Netlify (pode usar o drop simples agora, não precisa mais de Functions).

## ✅ Testar

1. Abra `https://[seu-site].netlify.app/?host=true`
2. Clique **🔌 TESTAR API**
3. Deve aparecer: **✅ FIREBASE OK!**
4. Abra a URL principal em 2 navegadores diferentes, jogue, e veja se aparecem juntos no ranking

## 🛠 Resetar entre workshops

No modo host (`?host=true`), clica em **🗑 RESETAR** — apaga todos os scores do Firebase. Pronto pra próximo workshop.

## 🔒 Segurança

O modo "TEST MODE" do Firebase libera acesso público por 30 dias. Depois disso:
1. Volta no Firebase Console
2. Realtime Database → **Rules**
3. Clica em "Edit rules"
4. Estende a data (ex: para 2027)

Pra workshop é seguro. Os participantes só veem nomes + scores (não dá pra acessar nada sensível porque NÃO TEM nada sensível ali).

## ⚠️ Limites do plano grátis

Firebase Realtime Database grátis:
- 1 GB armazenado (você usa ~10 KB pro workshop)
- 10 GB/mês download (super sobra)
- 100 conexões simultâneas — **importante:** se tiver mais de 100 participantes no MESMO segundo, alguns podem demorar pra carregar. Pra 200, sugiro:
  - Pedir pra participantes só abrirem o site quando você falar (não todos de uma vez)
  - OU upgrade pra plano "Blaze" (pay-as-you-go, ~$0.01/mês de uso de workshop)

---
© DBOUT MÍDIA · Laura Oliveira
