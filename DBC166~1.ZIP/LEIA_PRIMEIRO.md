# 🚨 LEIA PRIMEIRO — Como fazer o ranking funcionar

## ❌ O que NÃO funciona

**`https://app.netlify.com/drop` (drag-and-drop simples) NÃO deploya Functions.**
Isso é uma limitação do Netlify, não do código. Por isso o ranking não tava sincronizando entre navegadores.

## ✅ COMO FAZER FUNCIONAR (escolha um dos 2 caminhos)

### 🟢 CAMINHO MAIS FÁCIL — Netlify CLI (5 minutos, uma vez só)

Abre o **Terminal** (Mac) ou **PowerShell** (Windows) e roda:

```bash
# Passo 1: Instalar Netlify CLI (uma vez só)
npm install -g netlify-cli

# Passo 2: Login (abre o navegador, você loga na sua conta Netlify)
netlify login

# Passo 3: Navega até a pasta do projeto
cd /caminho/para/dbout-oficina

# Passo 4: Deploy!
netlify deploy --prod
```

Pronto. O `netlify deploy --prod` faz:
- ✅ Sobe os arquivos estáticos
- ✅ Detecta e deploya a **Function** (`netlify/functions/ranking.js`)
- ✅ Aplica o `netlify.toml`
- ✅ Te dá a URL final

Pra updates depois, basta rodar `netlify deploy --prod` de novo.

### 🟢 CAMINHO ALTERNATIVO — Git (GitHub)

1. Sobe a pasta `dbout-oficina` num repo no GitHub
2. No Netlify: **Add new site → Import from Git** → seleciona o repo
3. Deploy automático

### ❌ NÃO USE: drag-and-drop simples
Functions não são detectadas. O ranking vai pra OFFLINE.

## ✅ Como verificar que deu certo

1. Acesse `https://[seu-site].netlify.app/api/ranking` direto
2. Deve aparecer `[]` (lista vazia) ou um JSON com participantes
3. Se aparecer "Page not found" → Function não foi deployada (tente Netlify CLI)

## 📞 No dia da oficina

1. Você (Laura) abre `https://[seu-site].netlify.app/?host=true` na sua tela
2. Compartilha SUA tela no Zoom mostrando o ranking
3. Os participantes acessam `https://[seu-site].netlify.app` (sem `?host=true`)
4. Eles fazem o jogo → param no certificado
5. **VOCÊ** vê o ranking ao vivo se atualizando, com top 3 em destaque

---
© DBOUT MÍDIA · Laura Oliveira · laura@dboutmidia.com.br
